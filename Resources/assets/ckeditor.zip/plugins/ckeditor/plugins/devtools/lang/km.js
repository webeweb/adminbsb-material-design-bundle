/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","km",{title:"ព័ត៌មាន​នៃ​ធាតុ",dialogName:"ឈ្មោះ​ប្រអប់​វីនដូ",tabName:"ឈ្មោះ​ផ្ទាំង",elementId:"អត្តលេខ​ធាតុ",elementType:"ប្រភេទ​ធាតុ"});